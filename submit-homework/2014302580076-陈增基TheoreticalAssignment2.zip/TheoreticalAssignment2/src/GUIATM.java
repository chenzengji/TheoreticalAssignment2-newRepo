 import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent; 
import javax.swing.JFrame; 
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea; 
import javax.swing.JOptionPane; 

import java.awt.AWTException;
import java.awt.GridLayout; 
import java.awt.Container; 
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent; 
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.JButton; 
import javax.swing.border.EmptyBorder;
public class GUIATM extends JFrame //implements ActionListener
{  
	private int wput=0;
	private JPanel mypanel;
    private static JTextArea GScreen;
    private static JTextArea CopyS;
    private static JTextArea slot1;
    private static JTextArea slot2;
    private JLabel note1;
    private JLabel note2;
    private JButton[] buttons;
    private static final String[] names = {"1","2","3","4","5","6","7","8","9","0","Enter"}; 
    private static String text1="";
    private PrintStream contain;
    public ATM myatm=new ATM();
    public GUIATM()throws AWTException, IOException
    {
    	
    	super("ATM");
    	
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 10, 450, 600);
		mypanel = new JPanel();
		mypanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		mypanel.setLayout(null);
		setContentPane(mypanel);
    	GScreen=new JTextArea(text1);
    	GScreen.setEditable(false);
    	CopyS=new JTextArea("");
    	CopyS.setEditable(false);
    	mypanel.add(GScreen);
    	GScreen.setBounds(20, 20, 400, 285);
    	note1=new JLabel("take cash here");
    	mypanel.add(note1);
    	note1.setBounds(200, 330, 200, 40);
    	note2=new JLabel("insert  deposit envelope here");
    	mypanel.add(note2);
    	note2.setBounds(200, 440, 200, 40);
    	slot1=new JTextArea("");
    	slot1.setEditable(false);
    	mypanel.add(slot1);
    	slot1.setBounds(200, 390, 200, 20);
    	slot2=new JTextArea("");
    	slot2.setEditable(false);
    	mypanel.add(slot2);
    	slot2.setBounds(200, 490, 200, 20);

    	buttons=new JButton[names.length];
    	
    	for( int i=0;i<names.length-2;i++)	addButton( buttons[i], i,i+1);	
    	addButton( buttons[9], 9,0);
	  buttons[10]=new JButton("ok");
	 // buttons[i].addActionListener(this);
	  buttons[10].setBounds(80,470,105,50);
	  mypanel.add(buttons[10]);
	
	  buttons[10].addActionListener(
			 new ActionListener(){
				 public void actionPerformed(ActionEvent event)
			    	{
					    
					 GScreen.setText(CopyS.getSelectedText()); 
					myatm.keypad.num=wput;
					wput=0;
					myatm.keypad.ready=true;
					                					               
		                          
					      					        					      					  
			    	}
			 } 
			  );
	 // add(mypanel);
    	//add(batm);
    }
 public static void addtext(String str){
	 GScreen.append(str);
 }
    public void addButton(JButton button,int i,int t){
    	 button=new JButton(names[i]);
    	  button.setBounds(25+55*(i%3),305+55*(i/3),50,50);
    	  mypanel.add(button);    	 
    	  button.addActionListener(
    			 new ActionListener(){
    				 public void actionPerformed(ActionEvent event)
    			    	{    					    
    					    wput=wput*10+t;
    					    text1=String.format("%d",t );					      					        					        					  
    					     GScreen.append(text1);    					        					      					  
    			    	}
    			                     } 
    			                        );  
    }  	
    
}
