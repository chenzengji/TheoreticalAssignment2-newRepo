//import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {public  boolean ready=false;
 public  int num=0; 
 //private Scanner input; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
// input = new Scanner( System.in );
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 { ready=false;
	 while(!ready){ System.out.print("");int a=0;a=0;}
	// System.out.print("");
	// String str=String.format("%d",GUIATM.getnput() );
	 //System.out.println(str );
 return num;//input.nextInt(); // we assume that user enters an integer
 } // end method getInput
 }