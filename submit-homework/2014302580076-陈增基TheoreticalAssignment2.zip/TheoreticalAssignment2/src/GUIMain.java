import java.awt.AWTException;
import java.io.IOException;


class GUIMain {

	public static void main(String[] args) throws AWTException, IOException{
		// TODO �Զ����ɵķ������
		GUIATM gui=new GUIATM();
		//GUI gui=new GUI();
		gui.setVisible(true);
		gui.myatm.run();
	}

}
