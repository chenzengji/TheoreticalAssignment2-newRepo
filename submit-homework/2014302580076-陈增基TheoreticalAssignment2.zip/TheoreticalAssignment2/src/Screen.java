
// Represents the screen of the ATM

public class Screen
 {
// display a message without a carriage return
 public void displayMessage( String message )
 {    GUIATM.addtext(message);
 //System.out.print( message );
 } // end method displayMessage

 // display a message with a carriage return
 public void displayMessageLine( String message )
 { GUIATM.addtext("\n"+message);
 //System.out.println( message );
 } // end method displayMessageLine

 // displays a dollar amount
 public void displayDollarAmount( double amount )
 { 
	 String stramount=String.format("$%,.2f", amount);
	 GUIATM.addtext(stramount);
	 //System.out.print(amount );
 } // end method displayDollarAmount
 } // end class Screen